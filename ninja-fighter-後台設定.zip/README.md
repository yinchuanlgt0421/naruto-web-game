# 忍者格鬥（聯線版）

## 這包裡有什麼
| 檔案 | 用途 |
|---|---|
| `index.html` | 遊戲本體（單一檔案，單人 / 雙人 / 聯線都在裡面） |
| `.nojekyll` | 讓 GitHub Pages 原樣提供檔案 |
| `server.js` `relay.js` `package.json` `Dockerfile` `render.yaml` | 聯線「後台」：同一個伺服器提供遊戲網頁 + WebSocket 中繼（不需要 npm install） |
| `optional-nextjs/` | 之前的 Next.js 版本（選用，沒有實際跑過，可忽略） |

## 方案 A：只用 GitHub Pages（最簡單）
1. 把 `index.html` 和 `.nojekyll` 放到儲存庫「根目錄」。
2. Settings → Pages → Branch 選 `main`、資料夾選 `/ (root)` → Save。
3. 開 `https://你的帳號.github.io/儲存庫名/`。
聯線會先用 WebRTC 直連（最快），連不上時自動改走公共 MQTT 中繼。單人、雙人本機對戰不受影響。

## 方案 B：自己的後台（聯線最穩）
需要能跑常駐 Node 的主機：Render / Railway / Fly.io / 自己的主機（Vercel、Netlify、GitHub Pages 不行）。
1. 把這個資料夾內容（不含 `optional-nextjs`）放到 GitHub 儲存庫根目錄。
2. Render：New → Web Service → 選該儲存庫 → Build Command 留空或 `echo ok`，Start Command `node server.js`。
3. 部署完開 `https://你的服務.onrender.com/healthz`，要看到 `{"ok":true,...}`；首頁就是遊戲。
本機測試：`node server.js` 然後開 http://localhost:3000

## 方案 A + B 合用
遊戲放 GitHub Pages、聯線走自己的後台：用這個網址開一次遊戲即可（會記住）：
`https://你的帳號.github.io/儲存庫名/?ws=wss://你的服務.onrender.com/ws`
或直接把 `index.html` 最上面的 `window.NF_WS=''` 改成 `window.NF_WS='wss://你的服務.onrender.com/ws'`。

## 聯線怎麼運作（為什麼比較順）
- 回滾式同步：你的操作立刻生效，不等對方；對方的操作晚到時，遊戲會自動倒回去重算。
- 兩邊只傳按鍵，不傳畫面；每 0.5 秒用血量/查克拉校正一次，避免不同瀏覽器的微小誤差累積。
- 戰鬥畫面右下角會顯示「直連 / 中繼」和延遲（ms）。

## 音效
全部用瀏覽器即時合成（打擊、灼燒、雷、水、風、土、結印、爆炸、格擋、KO），不需要音檔；施放招式時會用瀏覽器語音唸出招式名稱（需要裝置有中文語音）。按 `0` 切換：全開 / 無人聲 / 靜音。第一次按任何鍵後才會有聲音（瀏覽器限制）。

## 操作
P1：A/D/W/S、F 普攻、G/H 技能、T 大招、R 凝聚查克拉、Y 格擋。P2：方向鍵、K/L/;/O/P、I 格擋。Esc 暫停；聯線中連按兩次 Esc 離開。
