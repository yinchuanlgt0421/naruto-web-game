// Next.js 自訂伺服器：同一個埠同時提供網站 + WebSocket 中繼（/ws）
const http = require('http');
const next = require('next');
const relay = require('./relay');

const dev = process.env.NODE_ENV !== 'production';
const port = parseInt(process.env.PORT || '3000', 10);
const app = next({ dev, hostname: '0.0.0.0', port });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const upgradeNext = typeof app.getUpgradeHandler === 'function' ? app.getUpgradeHandler() : null;
  const server = http.createServer((req, res) => {
    if (req.url === '/healthz') { res.setHeader('content-type', 'application/json'); res.end(JSON.stringify({ ok: true, ...relay.stats() })); return; }
    handle(req, res);
  });
  server.on('upgrade', (req, socket, head) => {
    const path = (req.url || '').split('?')[0];
    if (path === '/ws') relay.handleUpgrade(req, socket, head);
    else if (upgradeNext) upgradeNext(req, socket, head);   // 開發模式的熱更新
    else socket.destroy();
  });
  server.listen(port, '0.0.0.0', () => console.log('ninja-fighter ready on :' + port + (dev ? ' (dev)' : '')));
});
