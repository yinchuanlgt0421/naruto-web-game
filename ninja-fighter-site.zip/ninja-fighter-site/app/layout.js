export const metadata = { title: '忍者格鬥 · 聯線版' };
export default function RootLayout({ children }) {
  return (<html lang="zh-Hant"><body>{children}</body></html>);
}
