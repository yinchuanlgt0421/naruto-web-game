// 首頁由 next.config.js 的 rewrite 轉到 /game.html，這頁只是保底。
export default function Page() {
  return <meta httpEquiv="refresh" content="0; url=/game.html" />;
}
