# 忍者格鬥 · 聯線版（Next.js + WebSocket）

- `public/game.html`：遊戲本體（單一 HTML）
- `relay.js`：WebSocket 中繼，無外部相依，只負責把同房間的訊息轉給對方
- `server.js`：Next.js 自訂伺服器，同一個埠同時提供網站與 `/ws`
- 網站首頁 `/` 直接是遊戲；`/healthz` 可看目前房間數

## 本機執行
```bash
npm install
npm run dev        # http://localhost:3000
# 正式模式
npm run build && npm start
```

## 變成常駐網站（任何裝置、任何人都能開）
必須部署到「能長時間跑 Node 程式」的主機（不能用 Vercel／Netlify，它們不支援常駐 WebSocket）。

**Render（免費方案可用）**
1. 把這個資料夾上傳到你的 GitHub 新倉庫
2. Render → New → Blueprint（或 Web Service），選該倉庫；`render.yaml` 已設定好
3. 部署完成會得到 `https://xxx.onrender.com`，把這個連結傳給朋友即可
   （免費方案閒置約 15 分鐘會休眠，第一次開啟要等 30～60 秒）

**Railway / Fly.io / 自己的 VPS**：Build `npm install && npm run build`，Start `npm start`，或直接用 `Dockerfile`。
設定環境變數 `PORT` 即可（預設 3000），前面若有反向代理請開啟 WebSocket。

## 聯線怎麼玩
主選單選「聯線對戰」→ 一人「生成代碼」、另一人「輸入代碼」→ 各自選角 → 開打。
兩邊都用 WASD／F／G／H／T／R；結束後 Enter 回選角，Esc 才會離開聯線。

## 為什麼順
- 兩邊各自跑完整遊戲，只同步「按鍵」，傳輸量極小
- 每個畫面格立刻送出按鍵（約 60 次/秒），伺服器零處理直接轉發，並關閉 Nagle（TCP_NODELAY）
- 輸入延遲依實際網路自動調整（每 0.7 秒量測一次來回時間），網路好時只延遲約 2 格（33ms）
- 公開頁面若沒有 `/ws`（例如單獨打開 HTML 檔）會自動改用公共 MQTT 中繼
