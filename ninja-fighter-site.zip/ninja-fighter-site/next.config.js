/** @type {import('next').NextConfig} */
module.exports = {
  // 網站首頁直接是遊戲（public/game.html）
  async rewrites() {
    return { beforeFiles: [{ source: '/', destination: '/game.html' }] };
  },
  async headers() {
    return [{ source: '/game.html', headers: [{ key: 'Cache-Control', value: 'no-cache' }] }];
  },
};
