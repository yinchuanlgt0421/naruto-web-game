# 忍者格鬥（聯線版）
零依賴，只需 Node 18+。這個資料夾本身就是專案根目錄（根目錄要看到 server.js、index.html、package.json）。

本機：`node server.js` → 開 http://localhost:3000
部署（要能跑常駐 Node + WebSocket）：Render / Railway / Fly.io / VPS。
- Render：New → Web Service → 選此 repo → Build Command 留空或 `echo ok`，Start Command `node server.js`。
- Vercel / Netlify / GitHub Pages 不支援常駐 WebSocket，不要用。
檢查：開 /healthz 應看到 {"ok":true,...}。
