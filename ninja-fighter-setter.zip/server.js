// 零依賴伺服器：同一個埠提供遊戲網頁 + WebSocket 中繼(/ws)。不需要 npm install。
const http = require('http'), fs = require('fs'), path = require('path');
const relay = require('./relay');
const port = parseInt(process.env.PORT || '3000', 10);
const FILE = path.join(__dirname, 'index.html');
const server = http.createServer((req, res) => {
  const p = (req.url || '/').split('?')[0];
  if (p === '/healthz') { res.setHeader('content-type', 'application/json'); return res.end(JSON.stringify({ ok: true, ...relay.stats() })); }
  if (p === '/' || p === '/index.html' || p === '/game.html') {
    fs.readFile(FILE, (e, b) => {
      if (e) { res.statusCode = 500; return res.end('index.html missing'); }
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache' });
      res.end(b);
    });
    return;
  }
  res.statusCode = 404; res.end('not found');
});
server.on('upgrade', (req, socket, head) => {
  if ((req.url || '').split('?')[0] === '/ws') relay.handleUpgrade(req, socket, head); else socket.destroy();
});
server.listen(port, '0.0.0.0', () => console.log('ninja-fighter ready on :' + port));
