# ninja-fighter-setter（後台設定）

這個資料夾只有「後台」。遊戲本體是另外的 `index.html`，**請把 `index.html` 放在和 `server.js` 同一層**。

## 檔案
| 檔案 | 用途 |
|---|---|
| `server.js` | 提供 `index.html` 網頁 + `/ws` 聯線中繼 + `/healthz` 檢查（不需要 npm install） |
| `relay.js` | WebSocket 中繼（跨網路對戰時，雙方只傳按鍵，由它轉送） |
| `package.json` `Dockerfile` `render.yaml` | 部署設定（Node 18+） |

## 本機測試
`node server.js` → 開 http://localhost:3000

## 部署（跨網路對戰要用）
需要能跑常駐 Node 的主機：Render / Railway / Fly.io / 自己的主機。Vercel、Netlify、GitHub Pages 不行。
1. 新建 GitHub 儲存庫，把這個資料夾的檔案 + `index.html` 一起放在根目錄。
2. Render：New → Web Service → 選該儲存庫 → Build Command 留空或 `echo ok`，Start Command `node server.js`。
3. 開 `https://你的服務.onrender.com/healthz`，看到 `{"ok":true,...}` 就成功；首頁就是遊戲。把首頁網址傳給朋友，雙方用同一個網址進去即可（不同網路、不同裝置都可以）。

## 只用 GitHub Pages（沒有後台）時
把 `index.html`（和一個空的 `.nojekyll`）放到儲存庫根目錄並開啟 Pages。聯線會先用 WebRTC 直連（含 STUN / TURN，可跨網路），失敗時改走公共 MQTT 中繼（四個備援伺服器）。
想讓 GitHub Pages 的遊戲改走你的後台：用 `https://你的帳號.github.io/儲存庫/?ws=wss://你的服務.onrender.com/ws` 開一次即可（會記住）。

## 聯線流暢度
回滾式同步：自己的操作立刻生效，對方的操作晚到時自動重算；每 0.5 秒用血量/查克拉校正。戰鬥畫面右下角顯示「直連 / 中繼」和延遲。
