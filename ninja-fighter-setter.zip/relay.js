// 極簡 WebSocket 中繼（無外部相依）：同一個 room 內，收到的文字訊息原封不動轉給其他人。
// 遊戲邏輯（同步按鍵、選角、聊天室狀態）全部在瀏覽器端，伺服器只負責「轉發」，所以延遲最低。
const crypto = require('crypto');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_ROOM = 8, MAX_MSG = 32 * 1024, MAX_RATE = 240; // 每秒訊息上限
const rooms = new Map();
let srvN = 0;

function frame(text, op = 0x1) {
  const d = Buffer.from(text);
  const n = d.length;
  let h;
  if (n < 126) h = Buffer.from([0x80 | op, n]);
  else if (n < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(n, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(n), 2); }
  return Buffer.concat([h, d]);
}

function handleUpgrade(req, socket, head) {
  const u = new URL(req.url, 'http://x');
  const key = req.headers['sec-websocket-key'];
  const room = u.searchParams.get('room') || '';
  const id = u.searchParams.get('id') || '';
  if (!key || String(req.headers.upgrade).toLowerCase() !== 'websocket' ||
      !/^[A-Za-z0-9_./-]{1,80}$/.test(room) || !/^[a-z0-9]{1,16}$/.test(id)) {
    socket.end('HTTP/1.1 400 Bad Request\r\n\r\n'); return;
  }
  let set = rooms.get(room);
  if (!set) { set = new Set(); rooms.set(room, set); }
  if (set.size >= MAX_ROOM) { socket.end('HTTP/1.1 503 Room Full\r\n\r\n'); return; }

  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);            // 不等待合併封包 → 低延遲
  socket.setKeepAlive(true, 30000);

  const c = { socket, id, alive: true, buf: Buffer.alloc(0), frag: null, tokens: MAX_RATE, last: Date.now() };
  set.add(c);

  const send = (o, data) => { if (o.socket.destroyed) return; if (o.socket.writableLength > 1 << 20) { o.socket.destroy(); return; } o.socket.write(data); };
  const broadcast = (text) => { const f = frame(text); for (const o of set) if (o !== c) send(o, f); };

  const close = () => {
    if (!set.has(c)) return;
    set.delete(c);
    if (set.size === 0) rooms.delete(room);
    else { const f = frame(JSON.stringify({ t: 'b', i: id, m: 'srv.' + (++srvN) })); for (const o of set) send(o, f); }
    socket.destroy();
  };

  const onData = (chunk) => {
    c.buf = c.buf.length ? Buffer.concat([c.buf, chunk]) : chunk;
    for (;;) {
      const b = c.buf;
      if (b.length < 2) return;
      const fin = !!(b[0] & 0x80), op = b[0] & 15, masked = !!(b[1] & 0x80);
      let len = b[1] & 127, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; const big = b.readBigUInt64BE(2); if (big > BigInt(MAX_MSG)) return close(); len = Number(big); off = 10; }
      if (len > MAX_MSG || !masked) return close();
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4);
      const p = Buffer.from(b.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < len; i++) p[i] ^= mask[i & 3];
      c.buf = b.subarray(off + 4 + len);

      if (op === 8) { try { socket.write(frame('', 8)); } catch (e) {} return close(); }
      if (op === 9) { send(c, frame(p.toString('latin1'), 10)); continue; }
      if (op === 10) { c.alive = true; continue; }
      if (op === 1 || op === 0) {
        if (op === 1) c.frag = [];
        if (!c.frag) continue;
        c.frag.push(p);
        if (!fin) continue;
        const text = Buffer.concat(c.frag).toString('utf8'); c.frag = null;
        const now = Date.now();
        c.tokens = Math.min(MAX_RATE, c.tokens + (now - c.last) / 1000 * MAX_RATE); c.last = now;
        if (--c.tokens < 0) return close();
        c.alive = true;
        broadcast(text);
      }
    }
  };
  socket.on('data', onData);
  socket.on('close', close);
  socket.on('error', close);
  if (head && head.length) onData(head);
}

setInterval(() => {                    // 心跳：清掉斷線的人
  for (const set of rooms.values()) for (const c of [...set]) {
    if (!c.alive) { c.socket.destroy(); continue; }
    c.alive = false;
    try { c.socket.write(frame('', 9)); } catch (e) {}
  }
}, 20000).unref();

module.exports = { handleUpgrade, stats: () => ({ rooms: rooms.size, players: [...rooms.values()].reduce((a, s) => a + s.size, 0) }) };
